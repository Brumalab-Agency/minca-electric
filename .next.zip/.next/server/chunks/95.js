"use strict";exports.id=95,exports.ids=[95],exports.modules={79248:(e,t,s)=>{s.d(t,{R:()=>c});var l=s(25036),a=s(16014),r=s.n(a);let c=({param:e,clases:t})=>l.jsx("div",{className:"btn-scooter lg:flex lg: lg:top-[60%] z-10 relative",children:l.jsx("button",{type:"button",className:`${r().className} antialiased text-[16px] w-full h-[52px] rounded-[62px] my-3 lg:w-[210px] ${t}`,children:e})})},7445:(e,t,s)=>{s.d(t,{t:()=>x});var l=s(25036),a=s(18027),r=s(55480),c=s(14295),i=s.n(c),o=s(16014),n=s.n(o);let x=async({titulo:e,tituloNegrita:t,ocultar:s})=>(0,l.jsxs)("div",{children:[l.jsx(r.ZP,{}),l.jsx(a.h,{}),(0,l.jsxs)("div",{className:"p-4 lg:px-12",children:[(0,l.jsxs)("h1",{className:`${i().className} antialiased text-[40px] lg:text-[64px] 2xl:text-[96px] text-[#111] leading-[50px] lg:flex lg:tracking-wide	lg:font-light lg:mt-[77px] uppercase lg:leading-[45px]`,children:[e,l.jsx("br",{}),l.jsx("b",{className:"lg:font-bold lg:ml-6 uppercase",children:t})]}),l.jsx("p",{className:`${n().className} antialiased text-[#111]/60 leading-[20px] max-w-[263px] my-[20px] lg:mt-9 lg:font-normal lg:text-[24px] 2xl:text-[32px] lg:leading-[34px] lg:max-w-[700px] lg:text-[#42454A] lg:tracking-wide`,children:"Mu\xe9vete sostenible, con estilo y eficiencia. Mu\xe9vete con Minca."}),l.jsx("hr",{className:`border border-0.5 border-solid border-[#42454A] mt-[52px] ${s}`})]})]})},89809:(e,t,s)=>{s.d(t,{l:()=>o});var l=s(25036),a=s(34807),r=s(2813),c=s(14295),i=s.n(c);let o=async({titulo:e,tituloSecundarioNegrita:t,urlVideo:s,clases:c})=>(await (0,a.Eg)(),(0,l.jsxs)("div",{className:"heroVideo relative lg:mt-20",children:[(0,l.jsxs)("div",{className:"mt-4",children:[l.jsx("video",{className:"hidden lg:block w-full h-[663px] object-cover  top-0",src:s,autoPlay:!0,muted:!0,loop:!0}),l.jsx("video",{className:"lg:hidden w-full h-[400px] object-cover  top-0",src:s,autoPlay:!0,muted:!0,loop:!0})]}),l.jsx("div",{className:"overlay h-[400px] w-full bg-[#111]/50 absolute top-0 flex flex-col items-start justify-center p-4 lg:h-[663px] lg:px-12",children:(0,l.jsxs)("div",{className:"lg:flex lg:justify-between lg:w-full",children:[l.jsx("div",{className:`${i().className} antialiased text-[50px] text-white grid lg:text-[90px]`,children:(0,l.jsxs)("div",{className:"flex flex-col justify-center items-start",children:[l.jsx("span",{className:"font-light capitalize",children:e}),l.jsx("span",{className:`-mt-6 font-bold lg:-mt-8 uppercase ${c}`,children:t})]})}),l.jsx("div",{children:l.jsx(r.default,{placeholder:"empty",alt:"publicidad",className:"hidden lg:block",src:"/Logo l\xedneas - Minca Electric.png",width:390,height:400})})]})})]}))},34701:(e,t,s)=>{s.d(t,{y:()=>c});var l=s(25036),a=s(14295),r=s.n(a);let c=()=>(0,l.jsxs)("div",{className:"carrusel-single-product-tambien-podria-interesarte grid h-auto lg:h-[730px] place-items-center px-4 py-[50px] lg:px-[48px]",children:[l.jsx("section",{children:l.jsx("h2",{className:`${r().className} lg:text-[48px] font-bold text-[32px]`,children:"Tambi\xe9n podr\xeda interesarte"})}),(0,l.jsxs)("section",{className:"flex h-full w-full items-center lg:justify-center gap-6 overflow-scroll lg:overflow-visible mt-[48px] lg:mt-0",children:[(0,l.jsxs)("div",{className:"block lg:flex flex-col justify-center text-center h-auto w-[200px] lg:w-[295px]",children:[l.jsx("img",{className:"h-[200px] lg:w-[295px] max-w-[295px] lg:h-auto",src:"/sigleProduct/minca-300-single-product.png",alt:"scooter minca 300w"}),(0,l.jsxs)("div",{className:"flex w-full flex-col items-start justify-center",children:[l.jsx("h2",{className:`${r().className} text-left lg:mt-[16px] lg:text-[20px] font-bold text-[#111] mt-[10px] text-base`,children:"Minca Scooter 350W"}),l.jsx("p",{className:`${r().className} lg:text-base text-[#111] text-[14px] font-medium`,children:"Last mile mode"}),(0,l.jsxs)("div",{className:"lg:mt-[20px] flex items-center justify-between gap-4",children:[l.jsx("p",{className:`${r().className}text-[#111] text-left text-[20px] font-bold`,children:"$2.100.000"}),l.jsx("span",{className:"hidden h-[28px] w-[58px] items-center justify-center rounded-full bg-[#FF3333] bg-opacity-10 px-2.5 py-0.5 text-[#FF3333] lg:inline-flex lg:h-7 lg:px-[14px] lg:py-[0px]",children:l.jsx("p",{className:`${r().className} whitespace-nowrap text-[12px] font-semibold antialiased`,children:"-20%"})})]})]})]}),(0,l.jsxs)("div",{className:"block lg:flex flex-col justify-center text-center h-auto w-[200px] lg:w-[295px]",children:[l.jsx("img",{className:"h-[200px] lg:w-[295px] max-w-[295px] lg:h-auto",src:"/sigleProduct/minca-500-single-product.png",alt:"scooter minca 500w"}),(0,l.jsxs)("div",{className:"flex w-full flex-col items-start justify-center",children:[l.jsx("h2",{className:`${r().className} text-left lg:mt-[16px] lg:text-[20px] font-bold text-[#111] mt-[10px] text-base`,children:"Minca Scooter 500W"}),l.jsx("p",{className:`${r().className} lg:text-base text-[#111] text-[14px] font-medium`,children:"Electric Freedom"}),(0,l.jsxs)("div",{className:"lg:mt-[20px] flex items-center justify-between gap-4",children:[l.jsx("p",{className:`${r().className}text-[#111] text-left text-[20px] font-bold`,children:"$3.780.000"}),l.jsx("span",{className:"hidden h-[28px] w-[58px] items-center justify-center rounded-full bg-[#FF3333] bg-opacity-10 px-2.5 py-0.5 text-[#FF3333] lg:inline-flex lg:h-7 lg:px-[14px] lg:py-[0px]",children:l.jsx("p",{className:`${r().className} whitespace-nowrap text-[12px] font-semibold antialiased`,children:"-20%"})})]})]})]}),(0,l.jsxs)("div",{className:"block lg:flex flex-col justify-center text-center h-auto w-[200px] lg:w-[295px]",children:[l.jsx("img",{className:"h-[200px] lg:w-[295px] max-w-[295px] lg:h-auto",src:"/sigleProduct/minca-800-single-product.png",alt:"scooter minca 800w"}),(0,l.jsxs)("div",{className:"flex w-full flex-col items-start justify-center",children:[l.jsx("h2",{className:`${r().className} text-left lg:mt-[16px] lg:text-[20px] font-bold text-[#111] mt-[10px] text-base`,children:"Minca Scooter 800W"}),l.jsx("p",{className:`${r().className} lg:text-base text-[#111] text-[14px] font-medium`,children:"Up Hill Mode            "}),(0,l.jsxs)("div",{className:"lg:mt-[20px] flex items-center justify-between gap-4",children:[l.jsx("p",{className:`${r().className}text-[#111] text-left text-[20px] font-bold`,children:"$4.275.000"}),l.jsx("span",{className:"hidden h-[28px] w-[58px] items-center justify-center rounded-full bg-[#FF3333] bg-opacity-10 px-2.5 py-0.5 text-[#FF3333] lg:inline-flex lg:h-7 lg:px-[14px] lg:py-[0px]",children:l.jsx("p",{className:`${r().className} whitespace-nowrap text-[12px] font-semibold antialiased`,children:"-20%"})})]})]})]}),(0,l.jsxs)("div",{className:"block lg:flex flex-col justify-center text-center h-auto w-[200px] lg:w-[295px]",children:[l.jsx("img",{className:"h-[200px] lg:w-[295px] max-w-[295px] lg:h-auto",src:"/sigleProduct/minca-1600-single-product.png",alt:"scooter minca 1600w"}),(0,l.jsxs)("div",{className:"flex w-full flex-col items-start justify-center",children:[l.jsx("h2",{className:`${r().className} text-left lg:mt-[16px] lg:text-[20px] font-bold text-[#111] mt-[10px] text-base`,children:"Minca Scooter 1600W"}),l.jsx("p",{className:`${r().className} lg:text-base text-[#111] text-[14px] font-medium`,children:"Two Wheel Drive"}),(0,l.jsxs)("div",{className:"lg:mt-[20px] flex items-center justify-between gap-4",children:[l.jsx("p",{className:`${r().className}text-[#111] text-left text-[20px] font-bold`,children:"$4.770.000"}),l.jsx("span",{className:"hidden h-[28px] w-[58px] items-center justify-center rounded-full bg-[#FF3333] bg-opacity-10 px-2.5 py-0.5 text-[#FF3333] lg:inline-flex lg:h-7 lg:px-[14px] lg:py-[0px]",children:l.jsx("p",{className:`${r().className} whitespace-nowrap text-[12px] font-semibold antialiased`,children:"-20%"})})]})]})]})]})]})},34807:(e,t,s)=>{s.d(t,{Eg:()=>r,O1:()=>x,P5:()=>n,UX:()=>d,VJ:()=>c,X1:()=>p,cK:()=>i,zJ:()=>o});let l=async e=>{let t=await fetch(`https://test.mincaelectric.com/graphql?query=${encodeURIComponent(e)}`,{method:"GET",headers:{"Content-Type":"application/json"}}),{data:s}=await t.json();return s},a=async e=>{let t=await fetch(`https://test.mincaelectric.com/graphql?query=${encodeURIComponent(e)}`,{method:"GET",headers:{"Content-Type":"application/json"}}),{data:s}=await t.json();return s.sliderProducts},r=async()=>{let e=`
  query Banner {
    banner {
      edges {
        node {
          banner {
            nombreBannerNegrita
            titleMarquee
            background
            titleBanner
            videoBannerPc {
              altText
              id
              mediaItemUrl
              mediaItemId
            }
          }
        }
      }
    }
  }
    `;try{let{banner:t}=await l(e);return t.edges.map(e=>e)}catch(e){throw console.error("Error fetching banner:",e),Error("Error fetching banner")}},c=async()=>{let e=`
  query ClientesAliados {
    clientesAliados(first:100) {
      nodes {
        clientesAliados {
          clientesaliado {
            mediaItemUrl
            mediaItemId
            altText
          }
        }
      }
    }
  }
    `;try{return(await l(e)).clientesAliados.nodes}catch(e){throw console.error("Error fetching banner:",e),Error("Error fetching banner")}},i=async()=>{let e=`
        query Hero {
          pages {
              edges {
                  node {
                      hero {
                          ancla1
                          ancla2
                          subTitulo
                          subTitulo2
                          titulo
                          tituloNegrita
                      }
                  }
              }
          }
      }

    `;try{return(await l(e)).pages.edges}catch(e){throw console.error("Error fetching hero:",e),Error("Error fetching hero")}},o=async()=>{let e=`
        query Scooter {
          sliderProducts(where: {orderby: {field: NAME_IN, order: ASC}}) {
            edges {
              node {
                sliderProductos {
                  ampere
                  bateria
                  description
                  descuento
                  distancia
                  fieldGroupName
                  kg
                  km
                  kmh
                  llanta
                  motor
                  nombreProducto
                  peso
                  pesoMaximo
                  precioActual
                  precioRebajado
                  pulgadas
                  slogan
                  subtitulo
                  tipo
                  tipoAutonomia
                  tipoBrushless
                  vatios
                  velocidadMaxima
                  velocidadNum
                  frenos
                  tipofrenos
                  imagen {
                    altText
                    sourceUrl
                    id
                  }
                  frenosNulo
                  pesoSc
                  tpeso
                  kgPesoScooter
                  tipoRodamiento
                }
                contentType {
                  node {
                    id
                  }
                }
              }
            }
          }
        }
    `;try{return await a(e)}catch(e){throw console.error("Error fetching scooters:",e),Error("Error fetching scooters")}},n=async()=>{let e=`
  query Testimonios {
    testimonios(first: 30) {
      nodes {
        testimonio {
          comentario
          nombreDeCliente
          rate
        }
        testimonioId
      }
    }
  }
    `;try{return await l(e)}catch(e){throw console.error("Error fetching testimonio:",e),Error("Error fetching testimonio")}},x=async()=>{let e=`
        query Productos {
          products {
            nodes {
              type
              name
              databaseId
              slug
              image {
                mediaItemUrl
              }
              
            }
          }
        }
    `;try{return await l(e)}catch(e){throw console.error("Error fetching productosPrueba:",e),Error("Error fetching productosPrueba")}},d=async()=>{let e=`
  query Entradas {
    posts {
      nodes {
        guid
        postId
        slug
        entradas {
          campoTexto
        }
        title
        featuredImage {
          node {
            altText
            mediaItemUrl
          }
        }
        categories {
          edges {
            node {
              name
            }
          }
        }
        dateGmt
      }
    }
  }
    `;try{return await l(e)}catch(e){throw console.error("Error fetching Entradas:",e),Error("Error fetching Entradas")}},p=async e=>{let t=`
        query GetEntradas {
          posts(where: {id: ${e}}) {
            nodes {
              postId
              slug
              entradas {
                campoTexto
                subtitulo
              }
              title
              featuredImage {
                node {
                  altText
                  mediaItemUrl
                }
              }
              categories {
                edges {
                  node {
                    name
                  }
                }
              }
              dateGmt
              
            }
          }
        }
  `;try{let e=await l(t);return console.log(e),e}catch(e){throw console.error("Error fetching Entradas:",e),Error("Error fetching Entradas")}};p(395)}};