(()=>{var e={};e.id=718,e.ids=[718],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},18499:(e,s,a)=>{"use strict";a.r(s),a.d(s,{GlobalError:()=>i.a,__next_app__:()=>x,originalPathname:()=>m,pages:()=>d,routeModule:()=>p,tree:()=>c});var t=a(50482),r=a(69108),l=a(62563),i=a.n(l),o=a(68300),n={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>o[e]);a.d(s,n);let c=["",{children:["(pages)",{children:["testdrive",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,80699)),"/home/mendozalz/Escritorio/GitHub/cms-headless-nextjs-wordpress/app/(pages)/testdrive/page.js"]}]},{}]},{"not-found":[()=>Promise.resolve().then(a.t.bind(a,69361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,96433)),"/home/mendozalz/Escritorio/GitHub/cms-headless-nextjs-wordpress/app/layout.js"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,69361,23)),"next/dist/client/components/not-found-error"]}],d=["/home/mendozalz/Escritorio/GitHub/cms-headless-nextjs-wordpress/app/(pages)/testdrive/page.js"],m="/(pages)/testdrive/page",x={require:a,loadChunk:()=>Promise.resolve()},p=new t.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/(pages)/testdrive/page",pathname:"/testdrive",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},72870:(e,s,a)=>{Promise.resolve().then(a.bind(a,82066)),Promise.resolve().then(a.bind(a,72644)),Promise.resolve().then(a.t.bind(a,31900,23))},80699:(e,s,a)=>{"use strict";a.r(s),a.d(s,{default:()=>g});var t=a(25036),r=a(70592),l=a(7445),i=a(89809),o=a(16014),n=a.n(o),c=a(14295),d=a.n(c),m=a(79248);let x=({clase:e,icono:s,titulo:a,direccion:r,ciudad:l,entreSemana:i,sabado:o,domingo:c,btn:x})=>t.jsx("div",{children:(0,t.jsxs)("section",{className:`${e} p-4 h-[400px] lg:hidden`,children:[(0,t.jsxs)("div",{className:"p-1",children:[t.jsx("img",{className:"w-[41px] h-[41px]",src:s,alt:"icon scooter"}),t.jsx("h1",{className:`${d().className} font-bold text-[40px]`,children:a}),t.jsx("h2",{className:`${d().className} font-semibold text-[24px] uppercase`,children:"chic\xf3"}),(0,t.jsxs)("div",{className:`${n().className} text-[14px] leading-[25px]`,children:[t.jsx("p",{children:"Cra. 11a #94a-56"}),t.jsx("p",{children:"Bogot\xe1, Colombia"}),t.jsx("br",{}),(0,t.jsxs)("span",{children:[t.jsx("p",{children:"Lunes a viernes: 10:00 a.m. - 7:00 p.m."}),t.jsx("p",{children:"S\xe1bados: 10:00 a.m. - 6:00 p.m."}),t.jsx("p",{children:"Domingos: 11:00 a.m. - 5:00 p.m."})]})]})]}),t.jsx(m.R,{param:x,clases:"bg-[#111] text-white h-[52px]"})]})}),p=()=>t.jsx("div",{children:[{id:1,direccion:"Cra. 11a #94a-56",ciudad:"Bogot\xe1, Colombia",entreSemana:"Lunes a viernes: 10:00 a.m. - 7:00 p.m.",sabado:"S\xe1bados: 10:00 a.m. - 6:00 p.m.",domingo:"Domingos: 11:00 a.m. - 5:00 p.m."},{id:2,direccion:"Cra. 11a #94a-56",ciudad:"Bogot\xe1, Colombia",entreSemana:"Lunes a viernes: 10:00 a.m. - 7:00 p.m.",sabado:"S\xe1bados: 10:00 a.m. - 6:00 p.m.",domingo:"Domingos: 11:00 a.m. - 5:00 p.m."},{id:3,direccion:"Cra. 11a #94a-56",ciudad:"Bogot\xe1, Colombia",entreSemana:"Lunes a viernes: 10:00 a.m. - 7:00 p.m.",sabado:"S\xe1bados: 10:00 a.m. - 6:00 p.m.",domingo:"Domingos: 11:00 a.m. - 5:00 p.m."}].map((e,s)=>t.jsx(x,{icono:"/showroom_icon.png",titulo:"SHOWROOM",clase:s%2==0?"bg-[#FFFFFF]":"bg-[#F0F1EB]",direccion:e.direccion,ciudad:e.ciudad,entreSemana:e.entreSemana,sabado:e.sabado,domingo:e.domingo,btn:"Agendar TestDrive"},e.id))}),h=()=>t.jsx("div",{className:"TestDrive",children:(0,t.jsxs)("div",{className:"carrusel w-full bg-[#F0F1EB] lg:px-0",children:[(0,t.jsxs)("section",{className:"flex h-full w-full lg:h-[665px]",children:[t.jsx("div",{className:"ladoIzquierdo grid h-full w-full place-items-center bg-[url(/testDrive/td1.jpg)] bg-cover bg-center"}),t.jsx("div",{className:"ladoDerecho hidden h-full w-full place-items-center bg-[#F0F1EB] text-[#111] lg:grid ",children:(0,t.jsxs)("div",{className:"",children:[(0,t.jsxs)("div",{className:"flex gap-4 ",children:[(0,t.jsxs)("div",{className:"columna-img mb-[25px] flex h-auto w-[60px] flex-col justify-end gap-6",children:[t.jsx("div",{className:"mb-[40px]",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/showroom_icon.png",alt:"icono de herramientas"})}),t.jsx("div",{className:"",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/map.png",alt:"pointer map"})}),t.jsx("div",{className:"",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/calendario.png",alt:"icono calendario"})})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"",children:[t.jsx("p",{className:`${n().className} text-left text-base`,children:"Visita nuestras sedes Minca:"}),t.jsx("h1",{className:`${d().className} mt-[50px] text-left text-[42px] font-bold uppercase`,children:"showroom"}),t.jsx("h2",{className:`${d().className} mb-[27px] text-left text-[26px] font-medium uppercase`,children:"chic\xf3"})]}),(0,t.jsxs)("div",{children:[t.jsx("div",{className:"",children:(0,t.jsxs)("p",{className:`${n().className} text-base`,children:["Cra. 11a #94a-56, Localidad de Chapinero, ",t.jsx("br",{})," ","Bogot\xe1, Colombia"]})}),(0,t.jsxs)("div",{className:"mt-6",children:[t.jsx("p",{className:`${n().className} text-base`,children:"Lunes a viernes: 10:00 a.m. - 07:00 p.m."}),t.jsx("p",{className:`${n().className} text-base`,children:"S\xe1bados: 10:00 a.m. - 06:00 p.m."}),t.jsx("p",{className:`${n().className} text-base`,children:"Domingos: 11:00 a.m. - 05:00 p.m."})]})]})]})]}),t.jsx("div",{className:"mx-auto ml-[60px] mt-6",children:t.jsx(m.R,{param:"Agendar Mantenimiento",clases:"border-2 border-[#111] bg-[#F0F1EB] lg:w-[342px] lg:h-[56px]"})})]})})]}),(0,t.jsxs)("section",{className:"flex h-full w-full lg:h-[665px]",children:[t.jsx("div",{className:"ladoDerecho hidden h-full w-full place-items-center bg-[#F0F1EB] text-[#111] lg:grid ",children:(0,t.jsxs)("div",{className:"",children:[(0,t.jsxs)("div",{className:"flex gap-4 ",children:[(0,t.jsxs)("div",{className:"columna-img mb-[25px] flex h-auto w-[60px] flex-col justify-end gap-6",children:[t.jsx("div",{className:"mb-[40px]",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/showroom_icon.png",alt:"icono de herramientas"})}),t.jsx("div",{className:"",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/map.png",alt:"pointer map"})}),t.jsx("div",{className:"",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/calendario.png",alt:"icono calendario"})})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"",children:[t.jsx("p",{className:`${n().className} text-left text-base`,children:"Visita nuestras sedes Minca:"}),t.jsx("h1",{className:`${d().className} mt-[50px] text-left text-[42px] font-bold uppercase`,children:"showroom"}),t.jsx("h2",{className:`${d().className} mb-[27px] text-left text-[26px] font-medium uppercase`,children:"chic\xf3"})]}),(0,t.jsxs)("div",{children:[t.jsx("div",{className:"",children:(0,t.jsxs)("p",{className:`${n().className} text-base`,children:["Cra. 11a #94a-56, Localidad de Chapinero, ",t.jsx("br",{})," ","Bogot\xe1, Colombia"]})}),(0,t.jsxs)("div",{className:"mt-6",children:[t.jsx("p",{className:`${n().className} text-base`,children:"Lunes a viernes: 10:00 a.m. - 07:00 p.m."}),t.jsx("p",{className:`${n().className} text-base`,children:"S\xe1bados: 10:00 a.m. - 06:00 p.m."}),t.jsx("p",{className:`${n().className} text-base`,children:"Domingos: 11:00 a.m. - 05:00 p.m."})]})]})]})]}),t.jsx("div",{className:"mx-auto ml-[60px] mt-6",children:t.jsx(m.R,{param:"Agendar Mantenimiento",clases:"border-2 border-[#111] bg-[#F0F1EB] lg:w-[342px] lg:h-[56px]"})})]})}),t.jsx("div",{className:"ladoIzquierdo grid h-full w-full place-items-center bg-[url(/testDrive/td2.jpg)] bg-cover bg-center"})]}),(0,t.jsxs)("section",{className:"flex h-full w-full lg:h-[665px]",children:[t.jsx("div",{className:"ladoIzquierdo grid h-full w-full place-items-center bg-[url(/testDrive/td3.jpg)] bg-cover bg-center"}),t.jsx("div",{className:"ladoDerecho hidden h-full w-full place-items-center bg-[#F0F1EB] text-[#111] lg:grid ",children:(0,t.jsxs)("div",{className:"",children:[(0,t.jsxs)("div",{className:"flex gap-4 ",children:[(0,t.jsxs)("div",{className:"columna-img mb-[25px] flex h-auto w-[60px] flex-col justify-end gap-6",children:[t.jsx("div",{className:"mb-[40px]",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/showroom_icon.png",alt:"icono de herramientas"})}),t.jsx("div",{className:"",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/map.png",alt:"pointer map"})}),t.jsx("div",{className:"",children:t.jsx("img",{className:"h-[50px] w-[50px]",src:"/calendario.png",alt:"icono calendario"})})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"",children:[t.jsx("p",{className:`${n().className} text-left text-base`,children:"Visita nuestras sedes Minca:"}),t.jsx("h1",{className:`${d().className} mt-[50px] text-left text-[42px] font-bold uppercase`,children:"showroom"}),t.jsx("h2",{className:`${d().className} mb-[27px] text-left text-[26px] font-medium uppercase`,children:"chic\xf3"})]}),(0,t.jsxs)("div",{children:[t.jsx("div",{className:"",children:(0,t.jsxs)("p",{className:`${n().className} text-base`,children:["Cra. 11a #94a-56, Localidad de Chapinero, ",t.jsx("br",{})," ","Bogot\xe1, Colombia"]})}),(0,t.jsxs)("div",{className:"mt-6",children:[t.jsx("p",{className:`${n().className} text-base`,children:"Lunes a viernes: 10:00 a.m. - 07:00 p.m."}),t.jsx("p",{className:`${n().className} text-base`,children:"S\xe1bados: 10:00 a.m. - 06:00 p.m."}),t.jsx("p",{className:`${n().className} text-base`,children:"Domingos: 11:00 a.m. - 05:00 p.m."})]})]})]})]}),t.jsx("div",{className:"mx-auto ml-[60px] mt-6",children:t.jsx(m.R,{param:"Agendar Mantenimiento",clases:"border-2 border-[#111] bg-[#F0F1EB] lg:w-[342px] lg:h-[56px]"})})]})})]}),t.jsx("div",{children:t.jsx(p,{})})]})}),g=()=>(0,t.jsxs)(t.Fragment,{children:[t.jsx(l.t,{titulo:"PRUEBA",tituloNegrita:"UNA MINCA"}),t.jsx(i.l,{titulo:"MINCA",tituloSecundarioNegrita:"Test drive.",clases:"capitalize"}),t.jsx(h,{}),t.jsx(r.$,{})]})},79248:(e,s,a)=>{"use strict";a.d(s,{R:()=>i});var t=a(25036),r=a(16014),l=a.n(r);let i=({param:e,clases:s})=>t.jsx("div",{className:"btn-scooter lg:flex lg: lg:top-[60%] z-10 relative",children:t.jsx("button",{type:"button",className:`${l().className} antialiased text-[16px] w-full h-[52px] rounded-[62px] my-3 lg:w-[210px] ${s}`,children:e})})},7445:(e,s,a)=>{"use strict";a.d(s,{t:()=>d});var t=a(25036),r=a(18027),l=a(55480),i=a(14295),o=a.n(i),n=a(16014),c=a.n(n);let d=async({titulo:e,tituloNegrita:s,ocultar:a})=>(0,t.jsxs)("div",{children:[t.jsx(l.ZP,{}),t.jsx(r.h,{}),(0,t.jsxs)("div",{className:"p-4 lg:px-12",children:[(0,t.jsxs)("h1",{className:`${o().className} antialiased text-[40px] lg:text-[64px] 2xl:text-[96px] text-[#111] leading-[50px] lg:flex lg:tracking-wide	lg:font-light lg:mt-[77px] uppercase lg:leading-[45px]`,children:[e,t.jsx("br",{}),t.jsx("b",{className:"lg:font-bold lg:ml-6 uppercase",children:s})]}),t.jsx("p",{className:`${c().className} antialiased text-[#111]/60 leading-[20px] max-w-[263px] my-[20px] lg:mt-9 lg:font-normal lg:text-[24px] 2xl:text-[32px] lg:leading-[34px] lg:max-w-[700px] lg:text-[#42454A] lg:tracking-wide`,children:"Mu\xe9vete sostenible, con estilo y eficiencia. Mu\xe9vete con Minca."}),t.jsx("hr",{className:`border border-0.5 border-solid border-[#42454A] mt-[52px] ${a}`})]})]})},89809:(e,s,a)=>{"use strict";a.d(s,{l:()=>n});var t=a(25036),r=a(34807),l=a(2813),i=a(14295),o=a.n(i);let n=async({titulo:e,tituloSecundarioNegrita:s,urlVideo:a,clases:i})=>(await (0,r.Eg)(),(0,t.jsxs)("div",{className:"heroVideo relative lg:mt-20",children:[(0,t.jsxs)("div",{className:"mt-4",children:[t.jsx("video",{className:"hidden lg:block w-full h-[663px] object-cover  top-0",src:a,autoPlay:!0,muted:!0,loop:!0}),t.jsx("video",{className:"lg:hidden w-full h-[400px] object-cover  top-0",src:a,autoPlay:!0,muted:!0,loop:!0})]}),t.jsx("div",{className:"overlay h-[400px] w-full bg-[#111]/50 absolute top-0 flex flex-col items-start justify-center p-4 lg:h-[663px] lg:px-12",children:(0,t.jsxs)("div",{className:"lg:flex lg:justify-between lg:w-full",children:[t.jsx("div",{className:`${o().className} antialiased text-[50px] text-white grid lg:text-[90px]`,children:(0,t.jsxs)("div",{className:"flex flex-col justify-center items-start",children:[t.jsx("span",{className:"font-light capitalize",children:e}),t.jsx("span",{className:`-mt-6 font-bold lg:-mt-8 uppercase ${i}`,children:s})]})}),t.jsx("div",{children:t.jsx(l.default,{placeholder:"empty",alt:"publicidad",className:"hidden lg:block",src:"/Logo l\xedneas - Minca Electric.png",width:390,height:400})})]})})]}))},34807:(e,s,a)=>{"use strict";a.d(s,{Eg:()=>l,O1:()=>d,P5:()=>c,UX:()=>m,VJ:()=>i,X1:()=>x,cK:()=>o,zJ:()=>n});let t=async e=>{let s=await fetch(`https://test.mincaelectric.com/graphql?query=${encodeURIComponent(e)}`,{method:"GET",headers:{"Content-Type":"application/json"}}),{data:a}=await s.json();return a},r=async e=>{let s=await fetch(`https://test.mincaelectric.com/graphql?query=${encodeURIComponent(e)}`,{method:"GET",headers:{"Content-Type":"application/json"}}),{data:a}=await s.json();return a.sliderProducts},l=async()=>{let e=`
  query Banner {
    banner {
      edges {
        node {
          banner {
            nombreBannerNegrita
            titleMarquee
            background
            titleBanner
            videoBannerPc {
              altText
              id
              mediaItemUrl
              mediaItemId
            }
          }
        }
      }
    }
  }
    `;try{let{banner:s}=await t(e);return s.edges.map(e=>e)}catch(e){throw console.error("Error fetching banner:",e),Error("Error fetching banner")}},i=async()=>{let e=`
  query ClientesAliados {
    clientesAliados(first:100) {
      nodes {
        clientesAliados {
          clientesaliado {
            mediaItemUrl
            mediaItemId
            altText
          }
        }
      }
    }
  }
    `;try{return(await t(e)).clientesAliados.nodes}catch(e){throw console.error("Error fetching banner:",e),Error("Error fetching banner")}},o=async()=>{let e=`
        query Hero {
          pages {
              edges {
                  node {
                      hero {
                          ancla1
                          ancla2
                          subTitulo
                          subTitulo2
                          titulo
                          tituloNegrita
                      }
                  }
              }
          }
      }

    `;try{return(await t(e)).pages.edges}catch(e){throw console.error("Error fetching hero:",e),Error("Error fetching hero")}},n=async()=>{let e=`
        query Scooter {
          sliderProducts(where: {orderby: {field: NAME_IN, order: ASC}}) {
            edges {
              node {
                sliderProductos {
                  ampere
                  bateria
                  description
                  descuento
                  distancia
                  fieldGroupName
                  kg
                  km
                  kmh
                  llanta
                  motor
                  nombreProducto
                  peso
                  pesoMaximo
                  precioActual
                  precioRebajado
                  pulgadas
                  slogan
                  subtitulo
                  tipo
                  tipoAutonomia
                  tipoBrushless
                  vatios
                  velocidadMaxima
                  velocidadNum
                  frenos
                  tipofrenos
                  imagen {
                    altText
                    sourceUrl
                    id
                  }
                  frenosNulo
                  pesoSc
                  tpeso
                  kgPesoScooter
                  tipoRodamiento
                }
                contentType {
                  node {
                    id
                  }
                }
              }
            }
          }
        }
    `;try{return await r(e)}catch(e){throw console.error("Error fetching scooters:",e),Error("Error fetching scooters")}},c=async()=>{let e=`
  query Testimonios {
    testimonios(first: 30) {
      nodes {
        testimonio {
          comentario
          nombreDeCliente
          rate
        }
        testimonioId
      }
    }
  }
    `;try{return await t(e)}catch(e){throw console.error("Error fetching testimonio:",e),Error("Error fetching testimonio")}},d=async()=>{let e=`
        query Productos {
          products {
            nodes {
              type
              name
              databaseId
              slug
              image {
                mediaItemUrl
              }
              
            }
          }
        }
    `;try{return await t(e)}catch(e){throw console.error("Error fetching productosPrueba:",e),Error("Error fetching productosPrueba")}},m=async()=>{let e=`
  query Entradas {
    posts {
      nodes {
        guid
        postId
        slug
        entradas {
          campoTexto
        }
        title
        featuredImage {
          node {
            altText
            mediaItemUrl
          }
        }
        categories {
          edges {
            node {
              name
            }
          }
        }
        dateGmt
      }
    }
  }
    `;try{return await t(e)}catch(e){throw console.error("Error fetching Entradas:",e),Error("Error fetching Entradas")}},x=async e=>{let s=`
        query GetEntradas {
          posts(where: {id: ${e}}) {
            nodes {
              postId
              slug
              entradas {
                campoTexto
                subtitulo
              }
              title
              featuredImage {
                node {
                  altText
                  mediaItemUrl
                }
              }
              categories {
                edges {
                  node {
                    name
                  }
                }
              }
              dateGmt
              
            }
          }
        }
  `;try{let e=await t(s);return console.log(e),e}catch(e){throw console.error("Error fetching Entradas:",e),Error("Error fetching Entradas")}};x(395)}};var s=require("../../../webpack-runtime.js");s.C(e);var a=e=>s(s.s=e),t=s.X(0,[638,708,662,120,813,538,665],()=>a(18499));module.exports=t})();