(()=>{var e={};e.id=317,e.ids=[317],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44399:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>x,originalPathname:()=>g,pages:()=>c,routeModule:()=>m,tree:()=>d});var r=s(50482),a=s(69108),o=s(62563),l=s.n(o),n=s(68300),i={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(i[e]=()=>n[e]);s.d(t,i);let d=["",{children:["(pages)",{children:["blog",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,75624)),"/home/mendozalz/Escritorio/GitHub/cms-headless-nextjs-wordpress/app/(pages)/blog/[id]/page.js"]}]},{}]},{}]},{"not-found":[()=>Promise.resolve().then(s.t.bind(s,69361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,96433)),"/home/mendozalz/Escritorio/GitHub/cms-headless-nextjs-wordpress/app/layout.js"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,69361,23)),"next/dist/client/components/not-found-error"]}],c=["/home/mendozalz/Escritorio/GitHub/cms-headless-nextjs-wordpress/app/(pages)/blog/[id]/page.js"],g="/(pages)/blog/[id]/page",x={require:s,loadChunk:()=>Promise.resolve()},m=new r.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(pages)/blog/[id]/page",pathname:"/blog/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},72870:(e,t,s)=>{Promise.resolve().then(s.bind(s,82066)),Promise.resolve().then(s.bind(s,72644)),Promise.resolve().then(s.t.bind(s,31900,23))},75624:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>p});var r=s(25036),a=s(70592),o=s(14295),l=s.n(o),n=s(16014),i=s.n(n),d=s(34807);let c=({contenido:e})=>(0,r.jsxs)("div",{className:"BlogContent mt-[220px] lg:mt-[32px]",children:[r.jsx("h2",{className:`${l().className} text-[24px] text-[#111] font-bold`,children:e.entradas.subtitulo}),r.jsx("p",{className:`${i().className} text-[20px] mt-4 text-balance`,children:e.entradas.campoTexto}),r.jsx("div",{className:"w-full h-auto rounded-[12px] bg-[#F6F6F7] shadow-md grid place-items-center p-[32px] mt-[32px] mb-[67px] border-l-[#E8E8EA]",children:r.jsx("p",{className:` ${l().className}text-[#111] text-[24] font-normal leading-[32px]`,children:"“ Traveling can expose you to new environments and potential health risks, so it's crucial to take precautions to stay safe and healthy. ”"})})]});s(40002);let g=()=>r.jsx("div",{className:"px-4 mb-4",children:(0,r.jsxs)("div",{role:"status",className:"max-w-md animate-pulse space-y-4 divide-y divide-gray-200 rounded border border-gray-200 p-4 shadow md:p-6 dark:divide-gray-700 dark:border-gray-700",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsxs)("div",{children:[r.jsx("div",{className:"mb-2.5 h-2.5 w-24 rounded-full bg-gray-300 dark:bg-gray-600"}),r.jsx("div",{className:"h-2 w-32 rounded-full bg-gray-200 dark:bg-gray-700"})]}),r.jsx("div",{className:"h-2.5 w-12 rounded-full bg-gray-300 dark:bg-gray-700"})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between pt-4",children:[(0,r.jsxs)("div",{children:[r.jsx("div",{className:"mb-2.5 h-2.5 w-24 rounded-full bg-gray-300 dark:bg-gray-600"}),r.jsx("div",{className:"h-2 w-32 rounded-full bg-gray-200 dark:bg-gray-700"})]}),r.jsx("div",{className:"h-2.5 w-12 rounded-full bg-gray-300 dark:bg-gray-700"})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between pt-4",children:[(0,r.jsxs)("div",{children:[r.jsx("div",{className:"mb-2.5 h-2.5 w-24 rounded-full bg-gray-300 dark:bg-gray-600"}),r.jsx("div",{className:"h-2 w-32 rounded-full bg-gray-200 dark:bg-gray-700"})]}),r.jsx("div",{className:"h-2.5 w-12 rounded-full bg-gray-300 dark:bg-gray-700"})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between pt-4",children:[(0,r.jsxs)("div",{children:[r.jsx("div",{className:"mb-2.5 h-2.5 w-24 rounded-full bg-gray-300 dark:bg-gray-600"}),r.jsx("div",{className:"h-2 w-32 rounded-full bg-gray-200 dark:bg-gray-700"})]}),r.jsx("div",{className:"h-2.5 w-12 rounded-full bg-gray-300 dark:bg-gray-700"})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between pt-4",children:[(0,r.jsxs)("div",{children:[r.jsx("div",{className:"mb-2.5 h-2.5 w-24 rounded-full bg-gray-300 dark:bg-gray-600"}),r.jsx("div",{className:"h-2 w-32 rounded-full bg-gray-200 dark:bg-gray-700"})]}),r.jsx("div",{className:"h-2.5 w-12 rounded-full bg-gray-300 dark:bg-gray-700"})]}),r.jsx("span",{className:"sr-only",children:"Loading..."})]})});var x=s(7445),m=s(73674);let p=async({params:e})=>{let{id:t}=e,s=await (0,d.X1)(t);console.log(s.posts.nodes[0].postId),console.log(t);let o=s.posts.nodes;console.log(o[0].dateGmt);let n=new Date(o[0].dateGmt);console.log(n);let p=(0,m.WU)(n,"dd 'de' MMMM 'de' yyyy");return console.log(p),(0,r.jsxs)(r.Fragment,{children:[r.jsx(x.t,{titulo:"Blog"}),o.map(e=>(0,r.jsxs)("div",{className:"HeroBlog mt-[45px] grid-cols-3 lg:ml-[48px] lg:grid lg:min-h-[710px]",children:[(0,r.jsxs)("div",{className:"col-span-2",children:[(0,r.jsxs)("div",{className:"card-blog hidden h-[273px] w-full rounded-[12px] bg-white lg:block  lg:h-[220px] lg:w-[598px]",children:[r.jsx("button",{className:` ${i().className} h-[32px] w-[95px] rounded-[6px] bg-[#111] text-[14px] font-medium text-white`,children:e.categories.edges[0].node.name}),r.jsx("h2",{className:`${l().className} mb-6 mt-4 text-[24px] font-bold leading-[38px] text-[#111]`,children:e.title}),(0,r.jsxs)("div",{className:"flex items-center gap-4",children:[r.jsx("img",{className:"h-[33px] w-[30px]",src:"/imagotipo-negro.png",alt:"imagotipo"}),r.jsx("p",{className:`${i().className} text-[12px] text-[#97989F]`,children:"Minca Electric"}),r.jsx("p",{className:`${i().className} text-[12px] text-[#97989F]`,children:p})]})]}),(0,r.jsxs)("div",{className:"relative flex justify-center lg:justify-start",children:[r.jsx("div",{className:"relative flex h-[313px] w-full justify-center bg-cover bg-top lg:h-[603px] lg:w-full lg:justify-start lg:rounded-[12px]",style:{backgroundImage:`url(${e.featuredImage.node.mediaItemUrl})`}}),(0,r.jsxs)("div",{className:"card-blog absolute bottom-0 top-[60%] h-[273px] w-[90%] rounded-[12px] bg-white p-[40px] shadow-md lg:top-[75%] lg:ml-[192px] lg:hidden lg:h-[263px] lg:w-[598px]",children:[r.jsx("button",{className:` ${i().className} h-[28px] w-[80px] rounded-[6px] bg-[#111] text-[12px] font-medium text-white`,children:e.categories.edges[0].node.name}),r.jsx("h2",{className:`${l().className} mb-6 mt-4 text-[24px] font-bold leading-[30px] text-[#111]`,children:e.title}),(0,r.jsxs)("div",{className:"flex items-center gap-4",children:[r.jsx("img",{className:"h-[33px] w-[30px]",src:"/imagotipo-negro.png",alt:"imagotipo"}),r.jsx("p",{className:`${i().className} text-[12px] text-[#97989F]`,children:"Minca Electric"}),r.jsx("p",{className:`${i().className} text-[12px] text-[#97989F]`,children:p})]})]})]}),r.jsx("div",{className:"px-4 lg:px-0",children:r.jsx(c,{contenido:e})})]}),(0,r.jsxs)("div",{className:"h-30px hidden bg-white pt-[220px] lg:block",children:[r.jsx(g,{}),r.jsx(g,{}),r.jsx(g,{}),r.jsx(g,{})]})]})),r.jsx(a.$,{})]})}},7445:(e,t,s)=>{"use strict";s.d(t,{t:()=>c});var r=s(25036),a=s(18027),o=s(55480),l=s(14295),n=s.n(l),i=s(16014),d=s.n(i);let c=async({titulo:e,tituloNegrita:t,ocultar:s})=>(0,r.jsxs)("div",{children:[r.jsx(o.ZP,{}),r.jsx(a.h,{}),(0,r.jsxs)("div",{className:"p-4 lg:px-12",children:[(0,r.jsxs)("h1",{className:`${n().className} antialiased text-[40px] lg:text-[64px] 2xl:text-[96px] text-[#111] leading-[50px] lg:flex lg:tracking-wide	lg:font-light lg:mt-[77px] uppercase lg:leading-[45px]`,children:[e,r.jsx("br",{}),r.jsx("b",{className:"lg:font-bold lg:ml-6 uppercase",children:t})]}),r.jsx("p",{className:`${d().className} antialiased text-[#111]/60 leading-[20px] max-w-[263px] my-[20px] lg:mt-9 lg:font-normal lg:text-[24px] 2xl:text-[32px] lg:leading-[34px] lg:max-w-[700px] lg:text-[#42454A] lg:tracking-wide`,children:"Mu\xe9vete sostenible, con estilo y eficiencia. Mu\xe9vete con Minca."}),r.jsx("hr",{className:`border border-0.5 border-solid border-[#42454A] mt-[52px] ${s}`})]})]})},34807:(e,t,s)=>{"use strict";s.d(t,{Eg:()=>o,O1:()=>c,P5:()=>d,UX:()=>g,VJ:()=>l,X1:()=>x,cK:()=>n,zJ:()=>i});let r=async e=>{let t=await fetch(`https://test.mincaelectric.com/graphql?query=${encodeURIComponent(e)}`,{method:"GET",headers:{"Content-Type":"application/json"}}),{data:s}=await t.json();return s},a=async e=>{let t=await fetch(`https://test.mincaelectric.com/graphql?query=${encodeURIComponent(e)}`,{method:"GET",headers:{"Content-Type":"application/json"}}),{data:s}=await t.json();return s.sliderProducts},o=async()=>{let e=`
  query Banner {
    banner {
      edges {
        node {
          banner {
            nombreBannerNegrita
            titleMarquee
            background
            titleBanner
            videoBannerPc {
              altText
              id
              mediaItemUrl
              mediaItemId
            }
          }
        }
      }
    }
  }
    `;try{let{banner:t}=await r(e);return t.edges.map(e=>e)}catch(e){throw console.error("Error fetching banner:",e),Error("Error fetching banner")}},l=async()=>{let e=`
  query ClientesAliados {
    clientesAliados(first:100) {
      nodes {
        clientesAliados {
          clientesaliado {
            mediaItemUrl
            mediaItemId
            altText
          }
        }
      }
    }
  }
    `;try{return(await r(e)).clientesAliados.nodes}catch(e){throw console.error("Error fetching banner:",e),Error("Error fetching banner")}},n=async()=>{let e=`
        query Hero {
          pages {
              edges {
                  node {
                      hero {
                          ancla1
                          ancla2
                          subTitulo
                          subTitulo2
                          titulo
                          tituloNegrita
                      }
                  }
              }
          }
      }

    `;try{return(await r(e)).pages.edges}catch(e){throw console.error("Error fetching hero:",e),Error("Error fetching hero")}},i=async()=>{let e=`
        query Scooter {
          sliderProducts(where: {orderby: {field: NAME_IN, order: ASC}}) {
            edges {
              node {
                sliderProductos {
                  ampere
                  bateria
                  description
                  descuento
                  distancia
                  fieldGroupName
                  kg
                  km
                  kmh
                  llanta
                  motor
                  nombreProducto
                  peso
                  pesoMaximo
                  precioActual
                  precioRebajado
                  pulgadas
                  slogan
                  subtitulo
                  tipo
                  tipoAutonomia
                  tipoBrushless
                  vatios
                  velocidadMaxima
                  velocidadNum
                  frenos
                  tipofrenos
                  imagen {
                    altText
                    sourceUrl
                    id
                  }
                  frenosNulo
                  pesoSc
                  tpeso
                  kgPesoScooter
                  tipoRodamiento
                }
                contentType {
                  node {
                    id
                  }
                }
              }
            }
          }
        }
    `;try{return await a(e)}catch(e){throw console.error("Error fetching scooters:",e),Error("Error fetching scooters")}},d=async()=>{let e=`
  query Testimonios {
    testimonios(first: 30) {
      nodes {
        testimonio {
          comentario
          nombreDeCliente
          rate
        }
        testimonioId
      }
    }
  }
    `;try{return await r(e)}catch(e){throw console.error("Error fetching testimonio:",e),Error("Error fetching testimonio")}},c=async()=>{let e=`
        query Productos {
          products {
            nodes {
              type
              name
              databaseId
              slug
              image {
                mediaItemUrl
              }
              
            }
          }
        }
    `;try{return await r(e)}catch(e){throw console.error("Error fetching productosPrueba:",e),Error("Error fetching productosPrueba")}},g=async()=>{let e=`
  query Entradas {
    posts {
      nodes {
        guid
        postId
        slug
        entradas {
          campoTexto
        }
        title
        featuredImage {
          node {
            altText
            mediaItemUrl
          }
        }
        categories {
          edges {
            node {
              name
            }
          }
        }
        dateGmt
      }
    }
  }
    `;try{return await r(e)}catch(e){throw console.error("Error fetching Entradas:",e),Error("Error fetching Entradas")}},x=async e=>{let t=`
        query GetEntradas {
          posts(where: {id: ${e}}) {
            nodes {
              postId
              slug
              entradas {
                campoTexto
                subtitulo
              }
              title
              featuredImage {
                node {
                  altText
                  mediaItemUrl
                }
              }
              categories {
                edges {
                  node {
                    name
                  }
                }
              }
              dateGmt
              
            }
          }
        }
  `;try{let e=await r(t);return console.log(e),e}catch(e){throw console.error("Error fetching Entradas:",e),Error("Error fetching Entradas")}};x(395)}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[638,708,662,120,813,674,538,665],()=>s(44399));module.exports=r})();